#include <iostream>
using namespace std;

int main()
{
	const int n = 6, m = 3;
	int arr[n][m];
	int i, j;
	int k[n];

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			arr[i][j] = rand() % 21 - 10;
			cout << " ����� � - " << arr[i][j] << "\t";
		}
	}

	for (i = 0; i < n; i++)
	{
		if (k[i] < 0)
			k[i] = -1;
		if (k[i] > 0)
			k[i] = 1;
		if (k[i] = 0)
			k[i] = 0;
	}
	return 0;
}