#include <iostream>
using namespace std;

int main()
{
	const int n = 7;
	int arr[n][n];
	int i, j;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			arr[i][j] = 0 + rand();
			cout << " � - " << arr[i][j] << "\t";
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j = i; j++)
		{
			arr[i][j] *= 5;
		}

		for (j = 0; j > i; j++)
		{
			arr[i][j] = 0;
		}

		for (j = 0; j < i; j++)
		{
			arr[i][j] = abs(arr[i][j]);
		}
		cout << " ����� ����� � - " <<  arr[i][j] << " ";
	}

	cout << endl;

	return 0;
}
