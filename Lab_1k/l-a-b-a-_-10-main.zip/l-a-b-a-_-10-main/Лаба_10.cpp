﻿#include <iostream>
using namespace std;

int main()
{
	const int n = 3;
	const int m = 4;

	int arr[n][m] = {};

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			arr[i][j] = i + j;
			cout << "Масив А - " << arr[i][j] << " ";
		}
		cout << endl;
	}

	int brr[m][n];
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			brr[i][j] = arr[j][i];
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			cout << "Транспонований масив - "  << brr[i][j] << " ";
		}
		cout << endl;
	}

	int crr[n][m];
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			crr[i][j] = arr[i][j];
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			crr[i][j] += 10;
			cout << " Масив збільшений на 10 - " << crr[i][j] << " ";
		}
		cout << endl;
	}


	return 0;
}
