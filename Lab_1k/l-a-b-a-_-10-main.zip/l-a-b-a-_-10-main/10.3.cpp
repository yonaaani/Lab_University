#include <iostream>
using namespace std;

int main()
{
	const int n = 12;
	int arr[n][5];
    int i, j;
    double s;

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < 5; j++)
        {
            arr[i][j] = rand() % 11 - 5;
            cout << arr[i][j] << "\t";
        }
        cout << endl;
    }

    for (int i = 0; i < n; i++)
    {
        s = 0.0;
        for (int j = 0; j < n; j++)
            s += arr[i][j];
        s = s / 12.0;
        cout << " ������� ����������� = " << s << endl;
    }
    
	return 0;
}