#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	const int n = 5;
	int arr[n][n];
	int i, j;
	arr[0][0] = 1; arr[0][1] = 2; arr[0][2] = 3; arr[0][3] = 4; arr[0][4] = 5;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			arr[1][j] = pow(arr[i][j], 2);
			arr[2][j] = pow(arr[i][j], 3);
			arr[3][j] = pow(arr[i][j], 4);
			arr[4][j] = pow(arr[i][j], 5);

		}
	}
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
	cout << "����� - " << arr[i][j] << "\t";
	cout << endl;
	
	return 0;
}