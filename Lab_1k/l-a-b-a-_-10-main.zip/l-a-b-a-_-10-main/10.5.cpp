#include <iostream>
using namespace std;

int main()
{
	const int n = 8, m = 6;
	int arr[n][m];
	int i, j;
	int min, mini, minj;
	min = arr[0][0];

	// ���������� ������ 
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			arr[i][j] = rand()%11-5;
			cout << " ����� � - " << arr[i][j] << "\t";
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if(i+j <= n-1)
				if (arr[i][j] < min)
				{
					min = arr[i][j];
					mini = i;
					minj = j;

				}
		}
	}
	cout << "̳����� = " << min << "[" << mini << "," << minj << "]";
	return 0;
}
