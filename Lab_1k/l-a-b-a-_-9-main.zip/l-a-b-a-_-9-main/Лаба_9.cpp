﻿#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
  
	int n = 7;
	int arr[n], i,j, index, p;

	cout << "Введіть p - " << endl; 
	cin >> p;

	for (int i = 0; i < n; i++)
	{
		arr[i] = rand() % 31 - 10;    //тобто від [-10,20]
	}

	cout << "Всі елементи масиву a:" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << arr[i] << "\t";
		cout << " ";
	}

	for (int i = 0; i < n; i++)
	{
		if (arr[i] > p)            // перевірка, чи кожен елемент масиву більший за задане число p
		{
			if (i % 2 == 0)
			{
				for (j = i; j < n; j++)
				{
					arr[j] = arr[j + 1];
					n--;

					cout << "Всі елементи масиву a:" << endl;
					for (int i = 0; i < n; i++)
					{
						cout << arr[i] << "\t";
						cout << " ";
					}
			   }
			}
			else
			{
				for (j = i; j < n; j++)
				{
					arr[j] = arr[j + 1];
					n--;

					cout << "Всі елементи зміненого масиву a:" << endl;
					for (int i = 0; i < n; i++)
					{
						cout << arr[i] << "\t";
						cout << " ";
					}
				}
			}
		}
	}

	
	return 0;
}
