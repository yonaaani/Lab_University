#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
	const int n = 30;
	int arr[n];
	int i, j, index, t, sum =0;


	for (int i = 0; i < n; i++)
	{
		arr[i] = rand() % 21;
	}

	cout << "�� �������� ������ a:" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << arr[i] << "\t";
		cout << " ";
	}

	for (int i = 0; i < n; i++)
	{
		if (2 <= i && i <= 20 && i % 3 == 0)
		{
			sum = sum + arr[i];
			cout << "���� = " << sum << endl;
		}
		else
		{
			if (i % 2 == 0)
			{
				for (int j = i + 1; j < n; j++)
					if (arr[i] > arr[j])
					{
						t = arr[i];
						arr[i] = arr[j];
						arr[j] = t;
						for (int i = 0; i < n; i++)
							cout << "������� �����: " << arr[i] << "\t";
					}
			}
			if (i % 2 == 1)
			{
				for (int j = i + 1; j < n; j++)
					if (arr[i] < arr[j])
					{
						t = arr[i];
						arr[i] = arr[j];
						arr[j] = t;
						for (int i = 0; i < n; i++)
							cout << "������� �����: " << arr[i] << "\t";
					}
			}
		}
	}


	return 0;
}
