#include <iostream>
using namespace std;

int main()
{
	const int n = 7, m = 4;
	int arr[n][m];
	int i, j;       // k,p


	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			arr[i][j] = 0 + rand();
			cout << " � - " << arr[i][j] << "\t";
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			cout << "������ 1 ������ - " << i + 1 << " ����� - " << j + 1;
			cin >> arr[i][j];
		}
	}

	cout << endl;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << "\n";
	}

	return 0;

}