﻿#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	const int n = 5;
	int arr[n][n];
	int i, j, maxb, s = 0;
	int brr[n][n];
	double serb = 0;

	// заповнення масиву 
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			brr[i][j] = rand() % 21 - 10;
			cout << " Масив B - " << brr[i][j] << "\t";
		}
	}

	maxb = brr[0][0];

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (brr[i][j] > maxb)
				maxb = brr[i][j];
			cout << " Максимум = " << maxb << " ";
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			s += brr[i][j];
			serb = s / n / n;
			cout << " Середнє арифметичне - " << serb << " ";
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i == j)
				arr[i][j] = maxb;
			if (i + j == n - 1)
				arr[i][j] = serb;
		}
	}
	cout << " Новий масив - " << arr[i][j] << " ";
	return 0;
}