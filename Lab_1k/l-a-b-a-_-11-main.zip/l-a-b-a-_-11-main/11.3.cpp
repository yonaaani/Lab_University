#include <iostream>
using namespace std;

int main()
{
	const int n = 7, m = 4;
	int arr[n][m];
	int i, j;   
	int x=0, y=0;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			arr[i][j] = 0 + rand();
			cout << " � - " << arr[i][j] << "\t";
		}
	}

	for (i = 0; i < n; i++)
	{
		x++;
		for (int j = 0; j < m; j++)
		{
			if (arr[i][j] <= arr[i + 1][j + 1])
			{
				y++;
				cout << " ����� - " << x;
			}
		}
	}

	return 0;
}

