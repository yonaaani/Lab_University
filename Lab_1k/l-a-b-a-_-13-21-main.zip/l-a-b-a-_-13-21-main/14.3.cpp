#include <iostream>
#include <math.h>
using namespace std;


int Vstavka(int a[9])
{
	int n;
	a[9] = a[n];
	for (int i = 0; i < 9; i++)
	{
		if (a[i] == 0)
		{
			n++;
			for (int j = n - 1; j > i + 1; j--)
				a[j] = a[j - 1];
			a[i + 1] = Min(a);
		}
	}
	for (int i = 0; i < 9; i++)
	{
		if (a[i] == 0)
		{
			n++;
			for (int j = n - 1; j > i + 1; j--)
				a[j] = a[j - 1];
			a[i + 1] = Max(a);
		}
	}
}

int Min(int a[9])
{
	int mi;
	mi = a[0];

	for (int i = 0; i < 9; i++)
	{
		if (a[i] < mi)
		{
			mi = a[i];
		}
	}
	return mi;
}

int Max(int a[9])
{
	int ma;
	ma = a[0];

	for (int i = 0; i < 9; i++)
	{
		if (a[i] > ma)
		{
			ma = a[i];
		}
	}
	return ma;
}
int main()
{
	const int n = 9;
	int arr[n];
	int i, j;
	int min, max, vid;
	min = arr[0];
	max = arr[0];

	for (i = 0; i < n; i++)
	{
		arr[i] = 0 + rand();
		cout << " � - " << arr[i] << "\t";
	}

	min = Min(arr);
	max = Max(arr);
	vid = Vstavka(arr);
	return 0;
}