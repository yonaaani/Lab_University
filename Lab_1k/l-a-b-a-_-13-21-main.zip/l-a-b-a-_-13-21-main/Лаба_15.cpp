﻿#include <iostream>
using namespace std;

int main()
{
	const int n = 9;
	int arr[n];
	int i,max, sum;
	int *p;
	int first, last;

	for (i = 0; i < n; i++)
	{
		*(arr + i) = 0 + rand();
		cout << " А - " << *(arr+i) << "\t";
	}
	p = arr;
	max = *p;

	for (i = 0; i < n; i++)
	{
		if (abs(*p) > max)
			max = *p;
		p++;
	}
	cout << " Максимальне за модулем = " << max << endl;
	
	for (first = 0; first < n; first++)
	{
		if (*(arr + first) > 0)
			break;
	}
	for (last = n-1; last > first; last--)
	{
		if (arr[last] > 0) 
			break;
	}
	for (i = first + 1; i < last; i++)
	{
		sum += *(arr + i);
	}

	cout << " Сума = " << sum << endl;

	return 0;
}

