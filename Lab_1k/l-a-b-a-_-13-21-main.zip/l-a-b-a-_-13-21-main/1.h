#pragma once
#include <iostream>

const int n = 5;
int Zapovn(int a[n]);  
int Sort(int a[n]);
int Parn(int a[n]);
int Summ(int a[n]);
int Reverse(int n);
int Parni(int a[n]);
int Similar(int a[n]);

int main()
{
	int arr[n];
	arr[n] = Zapovn(arr);
	arr[n] = Sort(arr);
	arr[n] = Parn(arr);
	arr[n] = Summ(arr);
	arr[n] = Reverse(n);
	arr[n] = Parni(arr);
	arr[n] = Similar(arr);
}
