#include <iostream>
using namespace std;

int main()
{
	const int n = 14;
	int arr[n];
	int* t = arr;
    int k=0;

	for (int i = 0; i < n; i++)
	{
		*(arr + i) = 0 + rand();
		cout << " � - " << *(arr + i) << "\t";
	}

    for (int i = 0; i < n; i++)
    {
		if ((*(arr + i) != *(arr + i - 1)))
		{
			k += 1;
		}
    }
	cout << " ʳ������ ����� �������� = " << k << endl;
	return 0;
}