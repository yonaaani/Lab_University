﻿#include <iostream>
using namespace std;

int SumMin(int a[15])
{
	int s;
	for (int i = 0; i < 15; i++)
	{
		if (a[i] < 0)
			s += a[i];
	}
}

int SumKv(int a[15])
{
	int s, A, B, k, si;
	for (int i = 0; i < 15; i++)
	{
			s += a[i];
	}
	
	if (B <= 15)
	{
		for (int i = A; i <= B; i++)
		{
			si += (i * i);
			k = s / si;
		}
	}
	return k;
}

int main()
{
	const int n = 15;
	int arr[n];
	int i, j, k;
	int summ=0, sum=0;

	for (i = 0; i < n; i++)
	{
		arr[i] = 0 + rand();
		cout << " А - " << arr[i] << "\t";
	}

	summ = SumMin(arr);
	cout << " Сума мінімальних = " << summ << endl;

	int a, b;
	cout << " Введіть значення діапазону [a та b] - " << endl;
	cin >> a;
	cin >> b;

	k = SumKv(arr);
	cout << " Відповідь = " << k << endl;

	return 0;
}
