#include <iostream>
using namespace std;

int main()
{
	const int n = 10;
	int arr[n];
	int i, k;

	for (i = 0; i < n; i++)
	{
		*(arr + i) = 0 + rand();
		cout << " � - " << *(arr + i) << "\t";
	}
	for (i = 0; i < n; i++)
	{
		if (*(arr + i) < 0 && *(arr + i + 1) >= 0 || *(arr + i) >= 0 && *(arr + i + 1) < 0)
		{
			k++;
		}
	}
	cout << " ʳ������ - " << k << endl;

	return 0;
}