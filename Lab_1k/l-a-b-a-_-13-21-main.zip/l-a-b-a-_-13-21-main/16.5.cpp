#include <iostream>
using namespace std;

int main()
{
	const int n = 6;
	int arr[n][n];
	int i, j,sum=0;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			*(*(arr + i) + j) = 0 + rand();
			cout << " � - " << *(*(arr + i) + j) << "\t";
		}
	}
	for (i = 0; i < n; i++)
	{
		if (i == j)
			if (i + j == n - 1)
				for (j = 0; j < n; j++)
				{
					sum += *(arr + i);
				}
	}

	return 0;
}