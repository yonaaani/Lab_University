#include <iostream>
#include "1.h"
using namespace std;

int Similar(int a[n])
{
	int i, sum = 0;
	for (int i = 0; i < (n - 1); i++)
	{
		if ((*a + i) == (*a + i + 1))
		{
			sum = (*a + i) + (*a + i + 1);
			i = sum;
		}
	}
	for (int i = 0; i < n; i++)
	{
		cout << " S - " << *(a + i) << "\t";
	}
}