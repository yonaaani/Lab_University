﻿#include <iostream>
#include <math.h>
using namespace std;

float func_triangle(int x)
{
	float s;
	s = (pow(x, 2) * sqrt(3)) / 4;
	return s;
}

int main()
{
	int a;
	float sq;
	cout << " Введіть сторони a " << endl;
	cin >> a;

	if (a > 0)
	{
		cout << " Уху! Трикутник існує " << endl;
		sq = func_triangle(a);
		cout << " Площа рівностороннього трикутника = " << sq << endl;
	}
	else
	{
		cout << " Попробуйте ще раз)) " << endl;
	}

	return 0;
}
