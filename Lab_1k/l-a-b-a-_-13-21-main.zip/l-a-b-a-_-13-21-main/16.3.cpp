#include <iostream>
using namespace std;

int main()
{
	const int n = 15;
	int arr[n][n];
	int i, j,*p;
	int brr[n][n];


	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			*(*(arr + i) + j) = 0 + rand();
			cout << " � - " << *(*(arr + i) + j) << "\t";
		}
	}
	cout << endl;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			*(*(brr + i) + j) = *(*(arr + j) + i);
		}
	}

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			cout << " B - " << *(*(brr + i) + j) << "\t";
		}
	}
	return 0;
}



