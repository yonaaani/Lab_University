#include <iostream>
#include "1.h"
using namespace std;

int Reverse(int n) 
{
    int m = 0;
    while (n > 0) 
    {
        m *= 10;
        m += n % 10;
        n /= 10;
    }
    return m;
}