#include <iostream>
using namespace std;

int main()
{
	const int n = 15;
	int arr[n][n];
	int i, j, * p;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			*(*(arr + i) + j) = 0 + rand();
			cout << " � - " << *(*(arr + i) + j) << "\t";
		}
	}
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		int min = *(*(arr + i));
		for (int j = 1; j < n; j++)
			if (*(*(arr + i) + j) < min)
				min = *(*(arr + i) + j);
		cout << "̳�������� ��������� � " << i + 1 << " ����� = " << min << endl;
	}
	cout << endl;
	return 0;
}