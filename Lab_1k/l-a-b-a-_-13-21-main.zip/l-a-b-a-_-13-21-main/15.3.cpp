#include <iostream>
using namespace std;

int main()
{
	const int n = 12;
	int arr[n];
	int *p;
	int k;

	for (int i = 0; i < n; i++)
	{
		*(arr + i) = 0 + rand();
		cout << " � - " << *(arr + i) << "\t";
	}

	for (int i = 0; i < n-2; i++)
	{
		if (*(arr + i) > *(arr + i + 1) && *(arr + i + 1) > *(arr + i + 2))
			k++;
	}

	cout << " " << k << endl;

	return 0;
}