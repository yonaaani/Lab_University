#include <iostream>
#include "1.h"
using namespace std;

int Summ(int a[n])
{
	int i, num, sum = 0;
	num = *(a + i);
	while (num > 0)
	{
		sum = sum + num % 10;
		num = num / 10;
	}
	cout << " ���� = " << sum << endl;
	return 0;
}