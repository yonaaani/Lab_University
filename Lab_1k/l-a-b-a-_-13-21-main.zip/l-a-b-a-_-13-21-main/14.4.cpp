#include <iostream>
#include <math.h>
using namespace std;

const int n = 9;

int func(int a[n])
{
    int b[n / 3];
    int ser, i, sum=0, j;

    for (i = 0; i < 3; i++)
    {
        sum += a[i];
        ser = sum / 3;
        b[j] = ser;
    }

    return a[i];
}

int main()
{
    int arr[n], brr[n/3];
    int i, j;
    for (i = 0; i < 3 * n - 1; i++)
    {
        arr[i] = 0 + rand();
        cout << " � - " << arr[i] << "\t";
    }

    brr[j] = func(arr);
    cout << " B - " << brr[j] << "\t";
  

    return 0;
}