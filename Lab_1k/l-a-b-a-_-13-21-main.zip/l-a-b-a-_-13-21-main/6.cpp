#include <iostream>
#include "1.h"
using namespace std;

int Parni(int a[n])
{
	int p, i, m;
	int* b = new int[m];
	for (i = 0; i < n; i++)
	{
		if (i % 2 == 0)
		{
			*(b + i) = i;
			cout << " P - " << *(b + i) << "\t";
		}
		if (i % 2 == 1)
		{
			*(b + i) = i;
			cout << " -P - " << *(b + i) << "\t";
		}
	}
}