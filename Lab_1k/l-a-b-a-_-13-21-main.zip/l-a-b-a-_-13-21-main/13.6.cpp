#include <iostream>
#include <math.h>
using namespace std;

int z(int b[7])
{
	int i, j, t;
	for(i=0; i<7; i++)
		for(j=i+1; j<7; j++)
			if (b[i] > b[j])
			{
				t = b[i];
				b[i] = b[j];
				b[j] = t;
			}
}

int main()
{
	const int n = 7;
	int arr[n];
	int i, j;

	for (i = 0; i < n; i++)
	{
		arr[i] = 0 + rand();
		cout << " � - " << arr[i] << "\t";
		arr[i] = z(arr);
		cout << " " << arr[i];
	}

	return 0;
}