#include <iostream>
using namespace std;

int main()
{
	int n, i, j;
	int** a;
	a = new int* [n];
	int** b;
	b = new int* [n];
	int** c;
	c = new int* [n];

	cout << " ������ ������� ������� � �����  " << endl;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			*(*(a + i) + j) = 0 + rand();
			cout << " A - " << *(*(a + i) + j) << "\t";
		}
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			*(*(b + i) + j) = 0 + rand();
			cout << " B - " << *(*(b + i) + j) << "\t";
		}
	}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			c[i][j] = 0;
			for (int k = 0; k < n; k++)
				c[i][j] += a[i][k] * b[k][j];
		}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << " C - " << *(*(c + i) + j) << "\t";
		}
	}
	delete[]a[i];
	delete[]a;
	delete[]b[i];
	delete[]b;
	delete[]c[i];
	delete[]c;
	return 0;
}