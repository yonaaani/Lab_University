﻿#include <iostream>
using namespace std;

int main()
{
	const int n = 10;
	int arr[n][n];
	int i, j, sum = 0;
	int** p1;
	int* p2[n];
	p1 = p2;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			*(*(arr + i)+j) = 0 + rand();
			cout << " А - " << *(*(arr + i)+j) << "\t";
		}
	}
	cout << endl;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i == j)
				break;
			if (i + j == n - 1)
				break;
			else
				sum += *(*(arr + i) + j);
		}
	}
	cout << " Сума чисел, які не належать головній та бічній діагоналі = " << sum << endl;

	return 0;
}
