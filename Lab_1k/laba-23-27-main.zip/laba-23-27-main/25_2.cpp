﻿#include <iostream>
#include <stdlib.h>
#include <fstream>
using namespace std;
void random(int* a, int n);
void monetarandom(int* a, int n);
ofstream file("Zapus.txt");

int main()
{
    int sum=0;
    int n;
    cout << " Kilkist raziv vvedit - " << endl;
    cin >> n;
    int* kyb = new int [n];
    int *moneta = new int[n];

    if (n < 5)
    {
        system("Color F1");
    }
    else
    {
        system("Color F2");
    }

    cout << " rand zn kyba = " << endl;
    random(kyb,n);
    for (int i = 0; i < n; i++)
    {
        sum += kyb[i];
    }
    cout << " suma = " << sum;
    cout << endl;

    int k;  //kilkist oreliv
    monetarandom(moneta, n);
    for (int i = 0; i < n; i++)
    {
        if (moneta[i] = 1)
        {
            cout << " orel " << " ";
            k++;
        }
        else
            cout << " reshka " << " ";
    }

    if (sum > 42 && k<3)
    {
        int nsum = 0;
        for (int i = 0; i <= 10; i++)
        {
            nsum += kyb[i];
        }
        cout << " Seredne = " << nsum / n;
    }
    else
    {
        for (int i = 0; i < n; i++)
        {
            cout << *(kyb + i) << " ";
            file << *(kyb + i) << " ";
        }
        cout << endl;
        file << endl;

        for (int i = 0; i < n; i++)
        {
            cout << *(moneta + i) << " ";
            file << *(moneta + i) << " ";
        }
        cout << endl;
        file << endl;
    }

    delete[] kyb;
    return 0;
}

void random(int *a,int n)
{
    for (int i = 0; i < n; i++)
    {
        *(a + i) = rand() % 6 + 1;
    }
    for (int i = 0; i < n; i++)
    {
        cout << *(a + i) << " ";
    }
    cout << endl;
}

void monetarandom(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        *(a + i) = rand() % 1 + 1;
    }
}