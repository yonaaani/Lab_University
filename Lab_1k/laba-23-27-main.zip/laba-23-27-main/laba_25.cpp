﻿#include <iostream>
#include <fstream>
#include <functional>
using namespace std;

ofstream file("T.txt");
const int n = 9;
typedef int arr[n], brr[n], crr[n], drr[n];
void output(int a[], int n);
void sort(int a[], int n);
void first(int a[], int n);
void two(int a[], int n);
void three(int a[], int n);


int main()
{
	cout << " ___Masuvu:___ " << endl;
	arr a;
	brr b;
	crr c;
	drr d;
	cout << " A = " << " ";
	file << " A = " << " ";
	output(a, n);
	cout << " B = " << " ";
	file << " B = " << " ";
	output(b, n);
	cout << " C = " << " ";
	file << " C = " << " ";
	output(c, n);
	cout << " ___All sorts___ " << endl;

	void (*operation)(int arr[], int n);
	operation = sort;
	cout << " A = ";
	file << " A = ";
	(*operation)(a, n);
	cout << " B = ";
	file << " B = ";
	(*operation)(b, n);
	cout << " C = ";
	file << " C = ";
	(*operation)(c, n);

	int sum = 0;
	cout << " D = ";
	first(a, n);

	//на крайній випадок це знизу
	d[0] = (a[0] + b[0] + c[0]) / 3;
	d[3] = (a[3] + b[3] + c[3]) / 3;
	d[6] = (a[6] + b[6] + c[6]) / 3;

	d[1] = pow(a[1],2) + pow(b[1], 2) + pow(c[1], 2);
	d[4] = pow(a[4], 2) + pow(b[4], 2) + pow(c[4], 2);
	d[7] = pow(a[7], 2) + pow(b[7], 2) + pow(c[7], 2);

	d[2] = sqrt(pow(a[2], 2)) + sqrt(pow(b[2], 2)) + sqrt(pow(c[1], 2));
	d[5] = sqrt(pow(a[5], 2)) + sqrt(pow(b[5], 2)) + sqrt(pow(c[5], 2));
	d[8] = sqrt(pow(a[8], 2)) + sqrt(pow(b[8], 2)) + sqrt(pow(c[8], 2));

	cout << " " << endl;
	for (int i = 0; i < n; i++)
	{
		cout << *(d + i) << " ";
	}
	cout << endl;
	return 0;
}

// _____________________________________________________________________________________________________________________________
void output(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		*(a + i) = rand() % 16 + 10;
	}

	cout << " " << endl;
	for (int i = 0; i < n; i++)
	{
		cout << *(a + i) << " ";
		file << *(a + i) << " ";
	}
	cout << endl;
	file << endl;
}

// _____________________________________________________________________________________________________________________________
void sort(int a[], int n)
{
	int t;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
			if (*(a+i) > *(a+j))
			 {
				t = *(a + i);
				*(a + i) = *(a + j);
				*(a + j) = t;
			 }
	}
		
	cout << endl;
	cout << "Arr sort = ";
	file << endl;
	file << "Arr sort = ";
	for (int i = 0; i < n; i++)
	{
		cout << *(a + i) << " ";
		file << *(a + i) << " ";
	}
	cout << endl;
	file << endl;
}

// _____________________________________________________________________________________________________________________________
void first(int a[], int n)
{
	int j;
	int sumA = 0;
	for (int i = 0; i < n; i+3)
	{
		for (int j = i; j < n; j++)
		{
			a[j] = a[j + 1];
			n--;
		}
	}
	
}

// _____________________________________________________________________________________________________________________________
void two(int a[], int n)
{
	int j;
	int sumA = 0;
	for (int i = 1; i < n; i + 3)
	{
		for (int j = i; j < n; j++)
		{
			a[j] = a[j + 1];
			n--;
		}
	}

}

// _____________________________________________________________________________________________________________________________
void three(int a[], int n)
{
	int j;
	int sumA = 0;
	for (int i = 2; i < n; i + 3)
	{
		for (int j = i; j < n; j++)
		{
			a[j] = a[j + 3];
			n--;
		}
	}

}
// _____________________________________________________________________________________________________________________________