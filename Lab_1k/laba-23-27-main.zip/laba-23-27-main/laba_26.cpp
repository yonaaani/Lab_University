﻿#include <iostream>
#include <string.h>
#include <fstream>
using namespace std;
fstream file("text.txt");

class ticket
{
public:
    string punkt;
    int number;
    class time
    {
    public:

        int god;
        int hv;
        int sec;

        ticket:: time(int g, int h, int s)
        {
            god = g;
            hv = h;
            sec = s;
        }
        void print()
        {
            cout << "Chas: " << god << ":" << hv << ":" << sec << ".";
            cout << endl;
        }

        ticket::time()
        {
            god = 12;
            hv = 20;
            sec = 35;
        }
        ~time()
        {

        }
    };

    int kype;
    int plaz;

    int sum()
    {
        return kype + plaz;
    }
    int percent()
    {
        return kype / plaz;
    }

    ticket(string p, int n, int k, int pl)
    {
        punkt = p;
        number = n;
        kype = k;
        plaz = pl;
    }

    ticket()
    {
        punkt = "Lviv";
        number = 4;
        kype = 100;
        plaz = 75;
    }
    void output()
        {
        cout << " Punkt pruznachenna: " << punkt << endl;
        cout << " Nomer potaga: " << number << endl;
        cout << " Kilkist kype mistz: " << kype << endl;
        cout << " Kilkist plazkart mistz: " << plaz << endl;
        }

    void print()
    {
        cout << " Punkt pruznachenna: ";
        cin >> punkt;
        cout << endl;

        cout << " Nomer potaga: ";
        cin >> number;
        cout << endl;

        cout << " Kilkist kype mistz: ";
        cin >> kype;
        cout << endl;

        cout << " Kilkist plazkart mistz: ";
        cin >> plaz;
        cout << endl;
    }

    ~ticket()
    {

    }
};

//.......................................................................................................................................................

class employee
{
public:
    string surname;
    int plata;
    int rik;

    employee() : surname(string()), plata(int()), rik(int())
    {

    }
    void show()
    {
            cout << " Employee surname: ";
            file << " Employee surname: ";
            cin >> surname;
            file >> surname;
            cout << endl;
            file << endl;

            cout << " Plata: ";
            cin >> plata;
            cout << endl;

            cout << " Rik vstypy: ";
            cin >> rik;
            cout << endl;
        
    }

    int nadbavka()
    {
        return ((plata * 30) / 100);
        
    }
    
    int stash(int year=2022)
    {
        return year - rik;
    }

    ~employee()
    {

    }
};

//.......................................................................................................................................................

class library
{
public:
    string nazva;
    string avthor;
    int kilkist;
    int vartist;

    void show()
    {
        cout << " Book name: ";
        cin >> nazva;
        cout << endl;

        cout << " Avthor surname: ";
        cin >> avthor;
        cout << endl;

        cout << " Kilkist storinok: ";
        cin >> kilkist;
        cout << endl;

        cout << " Vartist: ";
        cin >> vartist;
        cout << endl;

        cout << " ------------------------------- " << endl;
    }

    void sort(library arr[], int n)
    {
        int t;
        string a = {'A','a'};
        for (int i = 0; i < n; i++)
        {
           if(arr[i].avthor == a)
            for (int j = i + 1; j < n; j++)
            {
                if (arr[i].vartist < arr[j].vartist)
                {
                    t = arr[i].vartist;
                    arr[i].vartist = arr[j].vartist;
                    arr[j].vartist = t;
                    cout << " sort: " << arr[i].vartist << " ";
                    file << " sort: " << arr[i].vartist << " ";
                }
            }
        }
        cout << endl;
    }

    void del(library arr[], int n)
    {
        int max;
        max = arr[0].vartist;
        for (int i = 0; i < n; i++)
            if (arr[i].vartist > max)
                max = arr[i].vartist;
        cout << " Max vatist= " << max << endl;
        for (int i = 0; i < n; i++)
        {
            if (arr[i].vartist == max)
            {
                for (int j = i; j < n; j++)
                {
                    arr[j].vartist = arr[j + 1].vartist;
                    n--;
                    cout << " del: " << arr[i].vartist << " ";
                }
            }
        }
        cout << endl;
    }

    void sobiv(library arr[],int n)
    {
        for (int i = 0; i < n; i++)
        {
            cout << "Sobiv= " << (arr[i].vartist / arr[i].kilkist);
        }
        cout << endl;
    }
};

//.......................................................................................................................................................

void menu()
{
    cout << " Oberit zavdanna: " << endl;
    cout << " 1." << endl;
    cout << " 2." << endl;
    cout << " 3." << endl;
}

int main()
{
    int x;
    do
    {
        menu();
        cin >> x;
        switch (x)
        {
        case 1:
        {
            ticket poisd("Chernivtsi", 5, 150, 25);
        poisd.print();
        ticket::time t(15, 30, 00);
        t.print();

        cout << " Suma mistz = " << poisd.sum() << endl;
        cout << " Spivvidnoshenia = " << poisd.percent() << endl;

        // другий конструктор
        cout << " _____________________________________________________________________ " << endl;
        ticket poizd;
        poizd.output();
        ticket::time tt;
        tt.print();
        cout << " Suma mistz = " << poizd.sum() << endl;
        cout << " Spivvidnoshenia = " << poizd.percent() << endl;
        } break;
        //.......................................................................................................................................................
        case 2:
        {
            employee pra[3];

            for (int i = 0; i < 3; i++)
            {
                pra[i].show();
                cout << endl;
                cout << " Nadbavka= " << pra[i].nadbavka() << endl;
                cout << " Stash = " << pra[i].stash() << endl;

                cout << " Zagal zarplata = " << pra[i].plata + pra[i].nadbavka() << endl;
                file << " Zagal zarplata = " << pra[i].plata + pra[i].nadbavka() << endl;
                cout << "------------------------" << endl;
                file << "------------------------" << endl;
            }
        }break;
        //.......................................................................................................................................................

        case 3:
        {
            const int n = 5;
            library book[n];

            for (int i = 0; i < n; i++)
            {
                book[i].show();
            }

            for(int i = 0; i < n; i++)
            {
                book[i].sort(book, n);
                book[i].del(book, n);
                book[i].sobiv(book, n);
                cout << endl;
            }

        }break;

        }
    } while (x == 3);
    
    return 0;
}

