﻿#include <iostream>
#include <fstream>
using namespace std;

ofstream file("log.txt");
void rand(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		*(a + i) = rand() % 900 + 100;
	}
}
// _____________________________________________________________________________________________________________________________
void sam(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cin >> *(a + i);
	}
}
// _____________________________________________________________________________________________________________________________
void input(int a[], int n)
{
	cout << "Choose operation" << endl;
	cout << "1.Randomize " << endl;
	cout << "2.For my deal " << endl;
	cout << "x = ";
	int x;
	cin >> x;
	//хотіла зробити зі switch, але воно якось не робить так як мені хотілося б, з if вроді +-, хоча б нормально виглядає
	if (x == 1)
	{
		rand(a, n);
	}
	if (x == 2)
	{
		sam(a, n);
	}
}
// _____________________________________________________________________________________________________________________________
void output(int a[], int n)
{
	cout << " Array = " << endl;
	for (int i = 0; i < n; i++)
	{
		cout << *(a + i) << " ";
		file << *(a + i) << " ";
	}
	cout << endl;
	file << endl;
}
// _____________________________________________________________________________________________________________________________
bool check = false;
void if0(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		if (*(a + i) % 100 == 0 && *(a + i) % 10 == 0) {
			cout << *(a + i) << " == " << "0\n";
			file << *(a + i) << " == " << "0\n";
		}
		else
		{
			cout << *(a + i) << " != " << "0\n";
			file << *(a + i) << " != " << "0\n";
		}
			
	}
	cout << endl;
	file << endl;
}
// _____________________________________________________________________________________________________________________________
void chuslo(int a[], int n)
{
	cout << " same number " << endl;
	file << " same number " << endl;
	for (int i = 0; i < n; i++)
	{
		// за допомогою вказівника
		// if ((a[i] / 10) % 10 != a[i] % 10 && a[i] / 100 != a[i] % 10 && a[i] / 100 != (a[i] / 10) % 10)
		if ((*(a + i) / 10) % 10 != *(a + i) % 10 && *(a + i) / 100 != *(a + i) % 10 && *(a + i) / 100 != (*(a + i) / 10) % 10)
		{
			cout << *(a + i) << " " << "not\n";
			file << *(a + i) << " " << "not\n";
		}
		else
		{
			cout << *(a + i) << " " << "is\n";
			file << *(a + i) << " " << "is\n";
		}
		cout << endl;
		file << endl;
	}
	
}
// _____________________________________________________________________________________________________________________________
void chuslodelete(int a[], int n)
{

	cout << "___delete same___" << endl;
	for (int i = 0; i < n; i++)
	{
		if ((*(a + i) / 10) % 10 != *(a + i) % 10 && *(a + i) / 100 != *(a + i) % 10 && *(a + i) / 100 != (*(a + i) / 10) % 10)
		{
		  for (int j = i; j < n; j++)
		  {
			  *(a + i) = *(a + j);
				n--;
		  }
		}
		cout << "Masuv =" << endl;
		cout << *(a + i) << " ";
		file << "Masuv =" << endl;
		file << *(a + i) << " ";
	}
	
}
// _____________________________________________________________________________________________________________________________
void if0sort(int a[], int n)
{
	int t;
	for (int i = 0; i < n; i++)
	{
		if (*(a + i) % 100 == 0 && *(a + i) % 10 == 0)
		{
			cout << a[i];
			for (int i = 0; i < n; i++)
			{
				for (int j = i + 1; j < n; j++)
					if (a[i] > a[j])
					{
						t = a[i];
						a[i] = a[j];
						a[j] = t;
					}
			}
		}
	}
	cout << endl;
	cout << "Arr sort without 0 = " << endl;
	file << endl;
	file << "Arr sort without 0 = " << endl;
	output(a, n);
}
// _____________________________________________________________________________________________________________________________
void del1and2(int a[], int n)
{
	int sum=0;
	cout << "___del 1 and 2___" << endl;
	for (int i = 0; i < n; i++)
	{
		if (*(a + i) % 10 == 1 || *(a + i) % 10 == 2)
		{
			cout << *(a + i) << " yes ";
			file << *(a + i) << " yes ";
		}
		else
		{
			cout << *(a + i) << " no ";
			file << *(a + i) << " no ";
		}
			
			if (*(a + i) % 10 == 1 || *(a + i) % 10 == 2)
			{
				sum += *(a + i);
				cout << "sum = " << sum << endl;
				file << "sum = " << sum << endl;
		    }
			
	}
}
// _____________________________________________________________________________________________________________________________

int main()
{
	file.open("log.txt");
	const int n = 7;
	int arr[n];

	if (file.is_open())
	{
	    input(arr, n);
		output(arr, n);
		if0(arr, n);
		if0sort(arr, n);
		chuslo(arr, n);
		chuslodelete(arr, n);
		del1and2(arr, n); 
	}
	file.close();

	return 0;
}


