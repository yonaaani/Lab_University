﻿#include <iostream>
#include <string>
using namespace std;


class abiturient
{
public:
    string surname, name;
    int mark1, mark2, mark3;

    void input()
    {
        cout << " Vvedit surname: " << endl;
        cin >> surname;

        cout << " Vvedit name: " << endl;
        cin >> name;

        cout << " Vvedit Math mark : " << endl;
        cin >> mark1;

        cout << " Vvedit Chemistry mark: " << endl;
        cin >> mark2;

        cout << " Vvedit Physics mark: " << endl;
        cin >> mark3;

    }

    void output()
    {
        cout << " All students: " << endl;
        cout << "______________________" << endl;
        cout << surname << endl;
        cout << name << endl;
        cout << mark1 << endl;
        cout << mark2 << endl;
        cout << mark3 << endl;
    }

    void nez(abiturient arr[], int n)
    {
        if (mark1 >= 3 || mark2 >= 3 || mark3 >= 3)
        {

        }
    }

};

class autopark
{
public:
    string surname, initsials;
    int number, year, probig;

    void input()
    {
        cout << " Vvedit name: " << endl;
        cin >> surname;

        cout << " Vvedit initsials: " << endl;
        cin >> initsials;

        cout << " Vvedit number of murshruts : " << endl;
        cin >> number;

        cout << " Vvedit start year: " << endl;
        cin >> year;

        cout << " Vvedit probig: " << endl;
        cin >> probig;

    }

    void output()
    {
        cout << " All drivers: " << endl;
        cout << "______________________" << endl;
        cout << surname << endl;
        cout << number << endl;
        cout << year << endl;
        cout << probig << endl;
    }

    void inf(int num)
    {
        if (num == number)
        {
            output();
        }
    }

    int age(int y)
    {
        return y - year;
    }

    void min(autopark arr[], int n)
    {
        int miin;
        miin = arr[0].probig;
        for (int i = 0; i < n; i++)
        {
            if (arr[0].probig < miin)
            {
                miin = arr[0].probig;
            }
        }

    }

    void sort(autopark arr[], int n)
    {
        int t;
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                t = arr[i].probig;
                arr[i].probig = arr[j].probig;
                arr[j].probig = t;
            }
        }
    }
};

int main()
{
    int num;
    int ye;
    const int n = 3;
    autopark arr[n];
    for (int i = 0; i < n; i++)
    {
        arr[i].input();
    }

    for (int i = 0; i < n; i++)
    {
        arr[i].output();
    }

    cout << "_____1_____" << endl;
    cout << endl;
    cout << " Vvedit nomer potribnogo marshryty: " << endl;
    cin >> num;

    for (int i = 0; i < n; i++)
    {
        arr[i].inf(num);
    }

    cout << "_____2_____" << endl;
    cout << " Vvedit rik: " << endl;
    cin >> ye;

        for (int i = 0; i < n; i++)
        {
            if(arr[i].age(ye) >= 10)
            cout << "Expluatation = " << arr[i].age(ye) << endl;
            arr[i].output();
        }

    cout << "_____3_____" << endl;
    int nn;
    cout << " Vvedit kilkist n avtobysiv: " << endl;
    cin >> nn;
    for (int i = 0; i < n; i++)
    {
        arr[i].min(arr, n);
        for (int i = 0; i < nn; i++)
        {
             arr[i].sort(arr, n);
        }
    }

    return 0;
}


