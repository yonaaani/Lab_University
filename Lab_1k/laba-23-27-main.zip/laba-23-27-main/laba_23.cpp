﻿#include <iostream>
#include <time.h>
#include <math.h>
using namespace std;

//ns1.................................................................
namespace ns1
{
	int i, n;
	void v(int A[], int n, int x, int y)
	{
		for (i = 0; i < n; i++) 
		{
			A[i] = rand() % 20 + 1;
			cout << A[i] << " ";
		}
		cout << endl;
	}

	void min(int A[]) {
	
		int minimum = 10;
		for (i = 0; i < n; i++) {

			if (minimum > A[i])
			{
				minimum = A[i];
			}
		}
	}

	void del(int A[], int num)
	{
		for (int i = num - 1; i < n; i++)
		{
			A[i] = A[i + 1];
		}

		n--;
		for (int i = 0; i < n; i++)
		{
			cout << A[i] << " ";
		}
		cout << endl;
	}
}
//ns2.....................................................................................
namespace ns2
{
	int i = 0, s = 0;
	void ar(int arr[], int n)
	{
		for (i = 0; i < n; i++)
		{
			arr[i] = rand() % 10;
			cout << arr[i] << " ";

		}
	}
	void v(int arr[], int n)
	{

		for (i = 0; i < n; i++)
		{
			cout << arr[i] << " ";
		}
	}
	void max(int a[], int n)
	{
		int max = a[0];
		for (i = 0; i < n; i++)
		{
			if (a[i] > max)
			{
				max = a[i];
			}
		}
		cout << max;
	}
	void del(int a[], int n, int z)
	{
		for (i = 0; i < n; i++)
		{
			if (a[i] == z)
			{
				for (int j = i; j < n; j++)
				{
					a[j] = a[j + 1];
				}
				n--;
			}
			cout << a[i] << " ";
		}
	}
}


using namespace ns1;
using namespace ns2;

int main()
{
	const int n = 9;
	int A[n];

	cout << " your array " << endl;
	ns1::v(A, n, -10, 10);

	for (int i = 0; i + 2 < n; i += 3)
	{
		ns2::s = A[i] + A[i + 1] + A[i + 2];
		cout << " sum 3x = " << ns2::s << endl;
		int b[3];
		for (int k = 0; k < 3; k++)
		{
			b[3] = A[i] + A[i + 1] + A[i + 2];
		}
		cout << "max and sum = ";
		for (int j = 0; j < 3; j++)
		{
			ns2::max(b, 3);
			cout << endl;
		}
	}

	cout << " _______sort_______" << endl;
	int t;
	for (ns1::i = 0; ns1::i < n; ns1::i++)
		for (ns2::i = ns1::i + 1; ns2::i < n; ns2::i++)
			if (A[ns1::i] > A[ns2::i])
			{
				t = A[ns1::i];
				A[ns1::i] = A[ns2::i];
				A[ns2::i] = t;
				cout << " sort masuv " << endl;
				ns2::v(A, ns1::i);
			}
	int p;
	cout << " write index ";
	cin >> p;
	if (p <= n)
	{
		ns1::del(A, p);
	}
	int p1;
	cout << " write x ";
	cin >> p1;
	ns2::del(A, n, p1);
	
	return 0;
}
	

	


	