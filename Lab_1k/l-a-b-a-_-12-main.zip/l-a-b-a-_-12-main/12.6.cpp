#include <iostream>
#include <string.h>
#include <stdio.h>
#include <cstring>
using namespace std;


int main()
{  
	int n, i, j;
	char vowel[] = "AEIOUY";
	char text[] = "my very beatiful string";

	puts(text);

	n = strlen(text);
	for (j = 0; j <= 5; j++)
	{
		for (i = 0; i <= n; i++)
			if (text[i] == vowel[j])
			{
				for (i = 0; i < n; i++)
				{
					while (text[i] == ' ' && i < n)
						i++;
					text[i] = toupper(text[i]);
					text[i] = tolower(text[i]);
					while (text[i] != ' ' && i < n)
						i++;
				}
			}
			else
			{
				for (int j = i; j < n; j++)
					text[j] = text[j + 1];
				n--;
			}
	}

	puts(text);

	return 0;
}
