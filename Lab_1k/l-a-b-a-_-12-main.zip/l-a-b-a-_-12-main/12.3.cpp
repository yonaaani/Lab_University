#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	string s = "2 3 4 5  76 4647 ";
	char ch[50];
	int i, n;
	n = strlen(ch);
	
	char* strcpy(char* ch, const char* s);
	puts(ch);

	return 0;
}