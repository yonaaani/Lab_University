#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	char s[] = "grj8vghk6ffk";
	char s0[] = "2jdfjfk5mr";
	int n, i;

	n = strlen(s);
	for (i = 0; i < n; i++)
	{
		s0[i] += s[i];
		n++;
		cout << " ������� ������ ����� - " << n << endl;
	}

	for (i = 0; i < n; i++)
	{
		if (s0[i]>='0' && s0[i] <= '9')
			s0[i] = '_';
	}

	puts(s);

	return 0;
}