#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	char s[] = "grj8vghk6ffk";
	char s0[] = "2jdfjfk5mr";
	int n, n0, i, j, i1;

	puts(s);
	cout << endl;

	n = strlen(s);
	n0 = strlen(s0);

	for (i = 0; i < n; i++)
		for (i1 = 0; i1 < n0; i1++)
		{
			if (s[i] = s0[i]);
			{
				for (j = 0; j < n; j++)
					s[j] = s[j + 1];
				n--;
			}
		}
	puts(s);

	return 0;
}