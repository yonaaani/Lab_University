#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;

int main()
{
    char s[12];
    int n;

    
    n = strlen(s);
    int a = 0;
    int kil = 0;

    for (int i = 1; i < n; i++) 
    {
        if (s[i] == 'a')
            a++;
        if (a == 3 && s[i] == ' ') 
        {
            kil = kil + 1; 
            a = 0;
        }
        if (s[i] == ' ' && a != 3) 
            a = 0;
    }

    cout << " ʳ������ 3-��� ��� � = " << kil << endl;
    return 0;
}
