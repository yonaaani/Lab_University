﻿#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	char s[] = "grj  vghk  ffk ";
	int n, i;

	puts(s);
	cout << endl;

	n = strlen(s);
	for(i=0; i < n; i++)
		if (s[i] == '  ')
		{
			for (int j = i; j < n; j++)
				s[j] = s[j + 1];
				n--;
		}
	puts(s);
	cout << endl;

	for (i = 0; i < n; i++)
	{
		if (s[i] <= i+2 )
			s[i] = '1','2','3','4','5';
	}

	puts(s);

	return 0;
}
